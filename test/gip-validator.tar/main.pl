#!/usr/bin/perl -w

use fetch_vors;
use Data::Dumper;
use glue_checker;
use strict;

my $html_base='/home/gip-validate/validator/www';
my $spacer_loc="/include/spacer.gif";

my @grids = (['is-itb.grid.iu.edu', "$html_base/itb", 4],['is.grid.iu.edu',"$html_base/production",'1']);

foreach my $grid (@grids) {
	create_pages($grid);
}

sub create_pages {
	my ($bdii_host,$html_dir,$gridtype)=@{shift(@_)};
#	my $bdii_host = 'is-itb.grid.iu.edu';
#	my $html_dir = "/var/www/html/osg-gip/dokuwiki/itb/";
	my $bdii_port = '2170';
	my $bdii_contact = 'mds-vo-name=local,o=grid';

	if (! -e $html_dir) {
		mkdir $html_dir or die "Cannot create $html_dir";
	}
	
	my $html_file = $html_dir . "/index.html";
	
	my $mapping = fetch_vors($gridtype);
	#print Data::Dumper->Dump([$mapping]);
	
	#my %sites = ('GROW-ITB' => 'grow-itb.its.uiowa.edu');
	#my $mapping = \%sites;
	
	my %glue_hash = ();
	do_ldap_search(\%glue_hash, $bdii_host, $bdii_port, $bdii_contact, "");
	
	#print Data::Dumper->Dump([%glue_hash]);
	
	my @attributes = ('GlueCEUniqueID', 'GlueCESEBindGroupCEUniqueID', 'GlueClusterUniqueID', 'GlueSEUniqueID', 'GlueSiteUniqueID'); 
	
	my $html_text = "<html>\n<body>\n<table>\n";
	
	my $attribute;
	
	$html_text .= "<tr>\n\t<td><h1>OSG-GIP Validator</h1></td>\n";
	
	$html_text .= "</tr>\n";
	$html_text .="<tr><td>Please click on the colored box to show more detailed information<br/><br/></td></tr>\n";
	$html_text .="<tr><td><b>Green</b> - GIP is reporting using CEMon and is configured properly</td></tr>\n";
	$html_text .="<tr><td><b>Red</b> - GIP is reporting using CEMon but may not be configured properly</td></tr>\n"; 
	$html_text .="<tr><td><b>Black</b> - GIP is not reporting using CEMon</td></tr>\n"; 
	$html_text .="<tr><td>&nbsp;</td></tr>\n"; 
	
	foreach my $sitename (sort keys %{$mapping}) {
	
		if (! -e "$html_dir/$sitename") {
			mkdir "$html_dir/$sitename";
		}
	
		my $site_html_text = "<html>\n<body>\n<table>\n<tr>\n\t<td>$sitename</td>\n</tr>\n";
	
		$html_text .= "<tr>\n";
		$html_text .= "\t<td valign='middle'>$sitename</td>\n";
	
		my $worst_error = 1;
	
		print "---- $sitename ----\n";
	
		if ($glue_hash{'mds-vo-name'}{$sitename}) {
			my %site_hash = %{$glue_hash{'mds-vo-name'}{$sitename}};
	
			my $output_string = "";
	
			foreach $attribute (keys %site_hash) {
			#foreach $attribute (@attributes) {
				my %error_hash = ();
	
				if ($attribute eq 'ObjectAttributes') { next; }
	
				$site_html_text .= "\n<tr>\n\t<td valign='top'>$attribute</td>\n";
	
				my ( $return_code, $error_text, $warning_text, $info_text ) = parse_attribute( \%site_hash, $attribute, \$output_string, \%error_hash );
	
				$site_html_text .= get_color($return_code, "$attribute.txt");
	
				open(ATTRIBUTE, ">$html_dir/$sitename/$attribute.txt") or die "Cannot open $html_dir/$sitename/$attribute.txt";
				print ATTRIBUTE Data::Dumper->Dump([$site_hash{$attribute}]);
				close(ATTRIBUTE);
	
				$site_html_text .= "<td valign='top' rowspan='2'>";
				foreach my $key (keys %error_hash) {
					$site_html_text .= "$key<br>\n";
	
					foreach my $key2 (keys %{$error_hash{$key}}) {
						$site_html_text .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$key2<br>\n";
	
						foreach my $tmphash (@{$error_hash{$key}{$key2}}) {
							$site_html_text .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;". $tmphash->{'attribute_name'} ."<br>\n";
							$site_html_text .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;". $tmphash->{'attribute'} . "=". $tmphash->{'value'} ."<br>\n";
						}
					}
				}
				$site_html_text .= "</td>\n";
	
	
				#print Data::Dumper->Dump([%site_hash]);	
				#print "-----  $output_string -----\n";
				#print "-- $return_code -- $error_text, $warning_text, $info_text ---\n";
				#print Data::Dumper->Dump([%error_hash]);
				
				if ($return_code > $worst_error) { $worst_error = $return_code; }
	
				$site_html_text .= "\n</tr>\n";
				$site_html_text .= "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>\n";
	
				print "---- $attribute ----\n";
				print Data::Dumper->Dump([%error_hash]);
			}
	
			$html_text .= get_color($worst_error, "$sitename/index.html");
	
		} else {
			$html_text .= "\t<td bgcolor='black' colspan=".($#attributes+1)."><img width='30' height='30' src='".$spacer_loc."' border='0'></td>\n";
		}
	
		$html_text .= "</tr>\n";
	
		$site_html_text .= "\n</table>\n</body>\n</html>\n";
	
		open(SITEHTML, ">$html_dir/$sitename/index.html") or die "Died at opening html_dir";
		print SITEHTML $site_html_text;
		print SITEHTML "Timestamp: " . localtime() ." GMT";
		close(SITEHTML);
	
	}
	
	$html_text .= "\n</table>\n</body>\n</html>\n";
	
	open(HTML, ">$html_file") or die("died at html_file");
	print HTML $html_text;
	print HTML "Timestamp: " . localtime() ." GMT";
	close(HTML);

}

sub get_color {
	my ($return_code, $link_text) = @_;
	my $color_text = "\t<td height='30' bgcolor='";
	if ($return_code == 1) {
		$color_text .= 'green';
	} elsif ($return_code == 2) {
		$color_text .= 'yellow';
	} elsif ($return_code == 3) {
		$color_text .= 'red';
	}

	$color_text .= "'><a href='$link_text'><img width='30' height='30' src='".$spacer_loc."' border='0'></a></td>\n";

	return $color_text;
}

