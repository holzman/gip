#!/usr/bin/perl -w

use Net::LDAP;
use Getopt::Long;
use strict;
use Data::Dumper;

###

my $hostname        = "localhost";
my $port            = 2135;
my $base            = "mds-vo-name=local,o=grid";    # base DN for search
my $attribute_store = "ObjectAttributes";
my $sitename;
my %glue_hash = ();

my $valid      = 1;
my $warning    = 2;
my $error      = 3;
my $null_error = '';

my $verbose    = 0;
my $all_errors = 0;
my $help = 0;
my $ldif_file;
my $ldif_exec;
my $osg_flag;
my $module = 0;

my $result = GetOptions(
	"h=s"  => \$hostname,
	"p=s"  => \$port,
	"b=s"  => \$base,
	"s=s"  => \$sitename,
	"v+"   => \$verbose,
	"m+"   => \$module,
	"all+" => \$all_errors,
	"help+" => \$help,
	"usage+" => \$help,
	"f=s" => \$ldif_file,
	"e=s" => \$ldif_exec,
	"osg+" => \$osg_flag
);

if ($help) {
	print "perl glue-checker.pl -h hostname -p port -b base_dn\n";
	exit 0;
}


my %glue_attributes = (
	'GlueSiteName'                                  => \&null_function,
	'GlueSiteDescription'                           => \&null_function,
	'GlueSiteUserSupportContact' 			=> \&valid_email_address,
	'GlueSiteSecurityContact'    			=> \&valid_email_address,
	'GlueSiteSysAdminContact'    			=> \&valid_email_address,
#	'GlueSiteUniqueID'                              => \&null_function,
#	'GlueSiteLatitude'  				=> \&valid_lat_long,
#	'GlueSiteLongitude' 				=> \&valid_lat_long,
#	'GlueSiteLocation'                              => \&null_function,
	'GlueSiteWeb' 					=> \&valid_website_address,


#	'GlueClusterName'                               => \&null_function,
#	'GlueClusterService'                            => \&null_function,
#	'GlueClusterUniqueID'                           => \&null_function,


#	'GlueSubClusterName'                            => \&null_function,
#	'GlueSubClusterUniqueID'                        => \&null_function,
	'GlueHostApplicationSoftwareRunTimeEnvironment' => \&null_function,
	# Should make these true / false
	'GlueHostNetworkAdapterInboundIP' 		=> \&null_function,
	'GlueHostNetworkAdapterOutboundIP'		=> \&null_function,
#	'GlueHostOperatingSystemName'                   => \&null_function,
#	'GlueHostProcessorModel'                        => \&null_function,
#	'GlueHostProcessorVendor'                       => \&null_function,
#	'GlueSubClusterPhysicalCPUs'			=> \&non_neg_integer,
#	'GlueSubClusterLogicalCPUs'			=> \&non_neg_integer,
	'GlueSubClusterWNTmpDir'			=> \&valid_unix_path,
	'GlueSubClusterTmpDir'				=> \&valid_unix_path,


	'GlueLocationName'                              => \&null_function,
#	'GlueLocationLocalID'                           => \&null_function,
#	'GlueLocationVersion'				=> \&null_function,
#	'GlueLocationPath'				=> \&valid_unix_path,
	'GlueLocationPath'				=> \&null_function,


	'GlueCEInfoContactString'			=> \&null_function,
	'GlueCEInfoDataDir'				=> \&valid_unix_path,
	'GlueCEInfoApplicationDir'			=> \&valid_unix_path,
	'GlueCEInfoDefaultSE'				=> \&null_function,
	'GlueCEStateStatus'				=> \&null_function,
	'GlueCEAccessControlBaseRule'			=> \&null_function,
#	'GlueCEHostingCluster'    => \&null_function,
	# could check for valid hostname (fqhn)
#	'GlueCEInfoHostName'                            => \&null_function,
#	'GlueCEInfoJobManager'                          => \&null_function,
#	'GlueCEInfoLRMSType'                            => \&null_function,
#	'GlueCEInfoLRMSVersion'                         => \&null_function,
#	'GlueCEName'                                    => \&null_function,
#	'GlueCEUniqueID'                                => \&null_function,
#	'GlueCEInfoGatekeeperPort'         => \&non_neg_integer,
#	'GlueCEInfoTotalCPUs'              => \&non_neg_integer,
#	'GlueCEPolicyAssignedJobSlots'     => \&non_neg_integer,
#	'GlueCEPolicyMaxCPUTime'           => \&non_neg_integer,
#	'GlueCEPolicyMaxRunningJobs'       => \&non_neg_integer,
#	'GlueCEPolicyMaxTotalJobs'         => \&non_neg_integer,
#	'GlueCEPolicyMaxWallClockTime'     => \&non_neg_integer,
#	'GlueCEPolicyPriority'             => \&non_neg_integer,
#	'GlueCEStateEstimatedResponseTime' => \&non_neg_integer,
#	'GlueCEStateFreeCPUs'              => \&non_neg_integer,
#	'GlueCEStateFreeJobSlots'          => \&non_neg_integer,
#	'GlueCEStateRunningJobs'           => \&non_neg_integer,
#	'GlueCEStateTotalJobs'             => \&non_neg_integer,
#	'GlueCEStateWaitingJobs'           => \&non_neg_integer,
#	'GlueCEStateWorstResponseTime'     => \&non_neg_integer,


#	'GlueVOViewLocalID'                             => \&null_function,


	'GlueSEName'                                    => \&null_function,
	'GlueSEUniqueID'                                => \&null_function,
	'GlueSEArchitecture'                            => \&null_function,
#	'GlueSEPort'                       => \&non_neg_integer,
#	'GlueSESizeFree'                   => \&non_neg_integer,
#	'GlueSESizeTotal'                  => \&non_neg_integer,


#	'GlueSEAccessProtocolLocalID'                   => \&null_function,
	'GlueSEAccessProtocolType'                      => \&null_function,
	'GlueSEAccessProtocolPort'         => \&non_neg_integer,
	'GlueSEAccessProtocolSupportedSecurity'         => \&null_function,
	'GlueSEAccessProtocolVersion'                   => \&null_function,


	'GlueSEControlProtocolEndpoint'                 => \&null_function,
	'GlueSEControlProtocolType'                     => \&null_function,
#	'GlueSEControlProtocolCapability'               => \&null_function,
#	'GlueSEControlProtocolLocalID'                  => \&null_function,
#	'GlueSEControlProtocolVersion'                  => \&null_function,


	'GlueSARoot'                                    => \&null_function,
	'GlueSAPath'                                    => \&null_function,
#	'GlueSAType'                                    => \&null_function,
#	'GlueSALocalID'                                 => \&null_function,
#	'GlueSAPolicyFileLifeTime'                      => \&null_function,
#	'GlueSAPolicyMaxData'                           => \&null_function,
#	'GlueSAPolicyMaxFileSize'                       => \&null_function,
#	'GlueSAPolicyMaxNumFiles'                       => \&null_function,
#	'GlueSAPolicyMaxPinDuration'                    => \&null_function,
#	'GlueSAPolicyMinFileSize'                       => \&null_function,
#	'GlueSAPolicyQuota'                             => \&null_function,
	'GlueSAAccessControlBaseRule' => \&null_function,
#	'GlueSAStateAvailableSpace'        => \&non_neg_integer,
#	'GlueSAStateUsedSpace'             => \&non_neg_integer,


#	'GlueCESEBindCEAccesspoint' => \&valid_unix_path,
#	'GlueCESEBindCEUniqueID'                        => \&null_function,
#	'GlueCESEBindGroupCEUniqueID'                   => \&null_function,
#	'GlueCESEBindGroupSEUniqueID'                   => \&null_function,
#	'GlueCESEBindMountInfo'                         => \&null_function,
#	'GlueCESEBindSEUniqueID'                        => \&null_function,
#	'GlueCESEBindWeight'                            => \&null_function,






	# The following attributes are just arbitrary strings
#	'GlueChunkKey'                                  => \&null_function,
#	'GlueForeignKey'                                => \&null_function,
#	'GlueInformationServiceURL'                     => \&null_function,
#	'GlueSchemaVersionMajor'                        => \&null_function,
#	'GlueSchemaVersionMinor'                        => \&null_function,


#	'GlueHostOperatingSystemRelease'                => \&null_function,
#	'GlueHostOperatingSystemVersion'                => \&null_function,
#	'GlueHostProcessorClockSpeed'                   => \&null_function,
#	'GlueServiceWSDL'				=> \&null_function,
#	'GlueServiceSemantics'				=> \&null_function,
#	'GlueServiceStatusInfo'				=> \&null_function,
#	'GlueServiceName'				=> \&null_function,
#	'GlueServiceUniqueID'				=> \&null_function,
#	'GlueServiceVersion'				=> \&null_function,
#	'GlueServiceEndpoint'				=> \&null_function,
#	'GlueServiceOwner'				=> \&null_function,
#	'GlueServiceType'				=> \&null_function,
#	'GlueServiceStatus'				=> \&null_function,
#	'GlueServiceStartTime'				=> \&null_function,


#	'GlueHostArchitectureSMPSize'      => \&non_neg_integer,
#	'GlueHostBenchmarkSF00'            => \&non_neg_integer,
#	'GlueHostBenchmarkSI00'            => \&non_neg_integer,
#	'GlueHostMainMemoryRAMSize'        => \&non_neg_integer,
#	'GlueHostMainMemoryVirtualSize'    => \&non_neg_integer,




#	'objectClass' => \&null_function
);

if ($module) {
	# do nothing
} else {
	if ($osg_flag) {
		my $vdt_location = $ENV{'VDT_LOCATION'};
		if (! $vdt_location) {
			die "Cannot find \$VDT_LOCATION";
		}
		
		$ldif_exec = "$vdt_location/lcg/libexec/osg-info-wrapper";
	}
	
	if (defined($ldif_file) || defined($ldif_exec)) {
	
		if (defined($ldif_file) && defined($ldif_exec)) {
			print "Cannot both read ldif from a file and from an executable\n";
			exit 1;
		}
		
		if (defined($ldif_file)) {
			do_ldif_search(\%glue_hash, $base, 'f', $ldif_file);
		} else {
			do_ldif_search(\%glue_hash, $base, 'e', $ldif_exec);
		}
		print "Validating LDIF output\n";
		
	} else {
	
		print "Searching ldap://$hostname:$port/$base\n";
		do_ldap_search( \%glue_hash, $hostname, $port, $base, $sitename );
		print "Validating LDAP output from $hostname\n";
		
	
	}
	
#	print Data::Dumper->Dump([%glue_hash]);
	
	my $return_code = parse_hash( \%glue_hash );
	exit $return_code;
}

sub validate_attribute {
	my ( $name, $value ) = @_;
	my $final_return_code = $valid;

	if ( $name eq 'objectClass' ) {
		return $valid;
	}
	else {
		if ( defined( $glue_attributes{$name} ) ) {
			my ( $return_code, $error_type, $error_text, $info_text ) = base_validity( $name, $value );
			if ( $return_code == $error ) {
				return $return_code, $error_type, $error_text, $info_text;
			}
			$final_return_code = merge_return_codes( $final_return_code, $return_code );
			return &{ $glue_attributes{$name} }($value);
		}
	}
}

sub validate_multiple_attributes {

# % attributes is a reference to a hash hashed by attributes, the value is a list
	my ( $attributes, $attribute_name, $attribute_value ) = @_;
	my $final_return_code = $valid;

	# errors is hashed by error type then error text then it's a list
	my %errors = ();

	foreach my $attribute ( keys %{$attributes} ) {
		foreach my $value ( @{ $attributes->{$attribute} } ) {
			my ( $return_code, $error_code, $error_text, $info_text ) = validate_attribute( $attribute, $value );
			$final_return_code = merge_return_codes( $final_return_code, $return_code );

			if ( $error_code && $error_text ) {

				if ( !defined( $errors{$error_code} ) ) {
					$errors{$error_code} = ();
				}

				if ( !defined( $errors{$error_code}{$error_text} ) ) {
					$errors{$error_code}{$error_text} = ();
				}

				my %attribute_hash = (
					'attribute_name'  => $attribute_name,
					'attribute'       => $attribute,
					'value'           => $value
				);
				push( @{ $errors{$error_code}{$error_text} },
					\%attribute_hash );
			}
		}
	}
	return $final_return_code, \%errors;
}

### Individual Tests ###
### These return three values, return code, error, and info
### one is true, zero is false, two is a warning

sub non_neg_integer {

	# InvalidNonNegativeInteger
	my ($possible_int) = @_;
	my $error_type = 'InvalidNonNegativeInteger';

	if ( $possible_int =~ /^[0-9]+$/ ) {
		return $valid, $null_error, "";
	}
	else {
		return $error, $error_type, "Not a non-negative integer";
	}
}

sub positive_integer {

	# InvalidPositiveInteger
	my ($possible_positive) = @_;
	my $error_type = 'InvalidPositiveInteger';

	# not the best detection, but it should work for all cases but 01
	if ( $possible_positive =~ /^[1-9][0-9]*$/ ) {
		return $valid, $null_error, "";
	}
	else {
		return $error, $error_type, "Not a positive integer";
	}
}

sub valid_lat_long {

	# InvalidLatLong
	my ($possible_lat_long) = @_;
	my $error_type = 'InvalidLatLong';

	if ( $possible_lat_long =~ /^-?([0-9]+)\.?[0-9]*/ ) {
		my $tmp = 0 + $1;
		if ( $tmp > 0 && $tmp <= 180 ) {
			return $valid, $null_error, "";
		}
	}
	return $error, $error_type, "Not a valid latitude or longitude";
}

sub vo_access_control_base {

	# VOAccessControlBase
	my ($value) = @_;
	my $error_type = 'VOAccessControlBase';

	if ( $value =~ /^VO:\S+/ ) {
		return $valid, $null_error, "";
	}
	return $error, $error_type, "Not a valid VOAccessControlBase (VO:thevo)";
}

sub valid_unix_path {

	# InvalidUnixPath
	my ($value) = @_;
	my $error_type = 'InvalidUnixPath';

	if ( $value =~ /^\// || $value eq 'UNAVAILABLE' || $value =~ /^[a-zA-Z]+:\/\/[a-zA-Z0-9.]+(:[0-9]+)?\//) {
		return $valid, $null_error, "";
	}
	return $error, $error_type, "Not a valid absolute unix path";
}

sub valid_email_address {

	# InvalidEmailAddress
	my ($value) = @_;
	my $error_type = 'InvalidEmailAddress';

	if ( $value =~ /^(mailto: )?.+@.+\..+$/ ) {
		return $valid, $null_error, "";
	} elsif ( $value =~ /^mailto:/) {
		return $valid, $null_error, "";
	}
	return $error, $error_type, "Not a valid email address";
}

sub valid_website_address {

	# InvalidWebsiteAddress
	my ($value) = @_;
	my $error_type = 'InvalidWebsiteAddress';

	if ( $value =~ /^(http|https):\/\// ) {
		return $valid, $null_error, "";
	}
	return $error, $error_type, "Not a valid website address";
}

sub null_function {
	return $valid;
}

### Tests for all attributes ###

sub gip_missing_newline_bug {
	my ($possible_newline_bug) = @_;

	if ( $possible_newline_bug =~ /^([^:]+):/ ) {
		if ( defined( $glue_attributes{$1} ) ) {
			return 1;
		}
	}

	return 0;
}

sub is_defined {
	my ($possible_defined) = @_;

	# don't do just if ($possible_defined) since we want 0 to count

	if ( !defined($possible_defined) ) {
		return 0;
	}

	if ( $possible_defined eq '' ) {
		return 0;
	}

	return 1;
}

sub is_default {
	my ( $name, $possible_default ) = @_;

	my @no_osg_attributes_defaults = (
		'^Change_Me_',          '^mailto: NOT-AVAILABLE$',
		'^NOT-AVAILABLE , US$', '^UNSPECIFIED$'
	);

	# run configure_osg

	foreach my $default (@no_osg_attributes_defaults) {
		if ( $possible_default =~ /$default/ ) {
			return 1;
		}
	}

	return 0;
}

sub configure_osg_default {
	my ( $name, $possible_default ) = @_;

	my @not_specified_these_values = ('^UNAVAILABLE$');

	# ignore locationpath since it doesn't have to be set
	if ( $name eq 'GlueLocationPath') { return 0; }

	# run it left unspecified
	

	foreach my $default (@not_specified_these_values) {
		if ( $possible_default =~ /$default/ ) {
			return 1;
		}
	}

	return 0;
}

sub base_validity {
	my ( $name, $value ) = @_;

	if ( !is_defined($value) ) {

		# NotDefined
		return $error, "NotDefined", "Value is not defined";
	}
	if ( is_default( $name, $value ) ) {

		# DefaultValue
		return $error, "DefaultValue", "Value is a default";
	}
	if ( configure_osg_default( $name, $value ) ) {
		return $error, "ConfigureOSGDefaultValue", "Value is a configure_osg default";
	}

	if ( gip_missing_newline_bug($value) ) {

		# GIPMissingNewline
		return $error, "GIPMissingNewline", "Bug in GIP, please report";
	}

	return $valid, $null_error, "";
}

### 1 -> valid 2 -> warning 3->error
sub merge_return_codes {
	my @list_of_codes = @_;

	my $original_code = shift(@list_of_codes);

	foreach my $new_code (@list_of_codes) {
		if ($new_code > $original_code) {
			$original_code = $new_code;
		}
	}

	return $original_code;
}

### LDAP Functions ###

sub do_ldap_search {

	my ( $ldap_hash, $hostname, $port, $base, $sitename ) = @_;
	my $msg;

	eval {
		local $SIG{ALRM} = sub { die "alarm clock restart" };
		alarm 60 * 5;

		my $ldap = Net::LDAP->new( $hostname, port => $port, timeout => 5 );
		if ( !$ldap ) {
			die "ldap object creation for host $hostname and port $port failed, check host and port";
		}

		$ldap->bind;

		$msg = $ldap->search(
			base   => $base,
			scope  => "sub",
			filter => "objectClass=*"
		);

		if ( $msg->code ) {

			if ( $msg->code == 53 ) {
				die 'Cannot verify authenticated ldap';
			}
		}

		$ldap->unbind;
		alarm 0;
	};

	if ($@) {
		if ( $@ =~ /alarm clock restart/ ) {
			print '[ Failure ] ldap functions hung\n';
			exit 1;
		}
		else {
			print '[ Failure ] ' . $@;
			exit 1;
		}
	}

	if ( $msg->count() > 0 ) {
		foreach my $entry ( $msg->all_entries() ) {
			add_entry( $ldap_hash, \$entry, $base );
		}
	}
}

sub do_ldif_search {
	my ($hashref, $base, $type, $filename) = @_;

	if ($type eq 'f') {
		open(LDIF, "$filename") or die "cannot open $filename for reading";
	} elsif ($type eq 'e') {
		open(LDIF, "$filename |") or die "cannot exec $filename";
	} else {
		die "Unknown type";
	}
	
	my $current_dn = "";
	my %attribute_hash = ();
	my $num_keys = 0;
	while (<LDIF>) {
		my $line = $_;
		if ($line =~ /^#/ || $line =~ /^search: / || $line =~ /^result: /) {
			# ignore me
		}
		
		if ($line =~ /^dn: (.*)$/) {
			$current_dn = $1;
			$num_keys = keys %attribute_hash;
			if ($num_keys != 0) {
				die "should not start new dn until expunging previous";
			}
		} elsif ($line =~ /^$/) {
			# new entry starting here
			$num_keys = keys %attribute_hash;
			if ($num_keys == 0) {
				# this is the first line ignore
			} else {
				# process stuff here
				
				my @add_entry_list = ();

				push @add_entry_list, $current_dn;
				$current_dn = "";

				my @current_attributes = keys %attribute_hash;
				push @add_entry_list, \@current_attributes;
				push @add_entry_list, \%attribute_hash;

				add_entry($hashref, \@add_entry_list, $base);
				
				%attribute_hash = ();
				
			}
		} elsif ($line =~ /([^:]+): (.*)$/) {
			# push stuff on here
			my $attribute = $1;
			my $value = $2;
			if (! defined($attribute_hash{$attribute})) {
				$attribute_hash{$attribute} = ();
			}
			push @{$attribute_hash{$attribute}}, $value;
					
		} else {
			die "Cannot parse line : $line\n";
		}
	}

	close(LDIF);
}

sub merge_error_hashes {
	my ( $into, $from ) = @_;

	foreach my $error_code ( keys %{$from} ) {

		if ( !defined( $into->{$error_code} ) ) {
			$into->{$error_code} = {};
		}

		foreach my $error_desc ( keys %{ $from->{$error_code} } ) {

			if ( !defined( $into->{$error_code}{$error_desc} ) ) {
				$into->{$error_code}{$error_desc} = ();
			}

			push(
				@{ $into->{$error_code}{$error_desc} },
				@{ $from->{$error_code}{$error_desc} }
			);
		}
	}
}

# pass the base attribute and a pointer to a string to return output
sub parse_attribute {
	my ( $hashref, $glue_attribute, $output_string, $error_hash ) = @_;
	my $final_return_code   = $valid;
	my $return_error_text   = "";
	my $return_warning_text = "";
	my $return_info_text    = "";
	my $attribute_exists    = 0;

	foreach my $attribute ( keys %{ $hashref->{$glue_attribute} } ) {

		$attribute_exists = 1;

		#print Data::Dumper->Dump([$hashref]);

		if (! defined( $hashref->{$glue_attribute}{$attribute}{$attribute_store})) {
			next;
			#FIXME: These will all be skipped
#			print STDERR Data::Dumper->Dump([$hashref]);
                        my %attribute_hash = (
                        	'attribute_name'  => $glue_attribute,
                        	'attribute'       => $attribute,
                        	#'value'           => $value
                        );
			my $tmp_error_code = 'MissingAttribute';
			my $tmp_error_text = "Missing $glue_attribute attributes";
			if (! defined($error_hash->{$tmp_error_code})) {
				$error_hash->{$tmp_error_code} = ();
			}
			if (! defined($error_hash->{$tmp_error_code}{$tmp_error_text})) {
				$error_hash->{$tmp_error_code}{$tmp_error_text} = ();
			}
                        push( @{ $error_hash->{$tmp_error_code}{$tmp_error_text} }, \%attribute_hash );

			$final_return_code = $error;
			next;
		}

		my %attributes1 = %{ $hashref->{$glue_attribute}{$attribute}{$attribute_store} };

		debug_print( 2, "\tRunning $glue_attribute : $attribute...\n" );

		my ( $return_code, $error_hashref ) = validate_multiple_attributes( \%attributes1, $glue_attribute, $attribute );

		merge_error_hashes( $error_hash, $error_hashref );
		$final_return_code = merge_return_codes( $final_return_code, $return_code );

		foreach my $sub_attribute (keys %{ $hashref->{$glue_attribute}{$attribute} }) {
			if ( $sub_attribute ne $attribute_store ) {
				my ($preturn_code, $perror_text, $pwarning_text, $pinfo_text,   $perror_hashref) = parse_attribute( $hashref->{$glue_attribute}{$attribute}, $sub_attribute, $output_string, $error_hash );
				$final_return_code = merge_return_codes( $final_return_code, $preturn_code );
			}
		}
	}

	if ( !$attribute_exists && $glue_attribute ne 'GlueSEUniqueID' ) {
		my $error_code = 'MissingGlueAttribute';
		my $error_text = 'Attribute Could not be found';
		$error_hash->{$error_code} = ();
		$error_hash->{$error_code}{$error_text} = ();
		my %attribute_hash = ( 'attribute_name' => $glue_attribute );
		push( @{ $error_hash->{$error_code}{$error_text} }, \%attribute_hash );

		# merge_error_hashes( $error_hash, \%errors );
		$final_return_code = $error;
	}

	return $final_return_code, $return_error_text, $return_warning_text, $return_info_text;
}

sub print_attribute_output {

	my ( $attribute, $return_code, $error_text, $warning_text, $info_text ) =
	  @_;

	print "Attribute:$attribute\n";

	if ( $return_code == $error ) {
		print "Display red status here\n";
	}
	elsif ( $return_code == $warning ) {
		print "Display yellow status here\n";
	}
	elsif ( $return_code == $valid ) {
		print "Display green status here\n";
	}

	print "Error: $error_text\n";
	print "Warning: $warning_text\n";
	print "Info: $info_text\n";

}

sub parse_hash {
	my ($hashref) = @_;
	my $output_string = "";
	my ( $return_code, $error_text, $warning_text, $info_text );
	my %error_hash;
	my $attribute_valid;

	my @attributes = (
		'GlueCEUniqueID',      'GlueCESEBindGroupCEUniqueID',
		'GlueClusterUniqueID', 'GlueSEUniqueID',
		'GlueSiteUniqueID'
	);

	my $all_attributes_valid = 1;

	my %found_errors = ();

	foreach my $attribute (@attributes) {
		%error_hash      = ();
		$attribute_valid = 1;
		print "\n$attribute: Validating attributes...\n";
		( $return_code, $error_text, $warning_text, $info_text ) = parse_attribute( $hashref, $attribute, \$output_string, \%error_hash );

#		print_attribute_output($attribute, $return_code, $error_text, $warning_text, $info_text);
		foreach my $error_code ( keys %error_hash ) {
			$attribute_valid      = 0;
			$all_attributes_valid = 0;
			print "\t[ Error ] $error_code - ";
			foreach my $error_desc ( keys %{ $error_hash{$error_code} } ) {
				print "$error_desc\n";

				my %duplicate_attributes = ();
				my %print_only_once      = ();

				foreach
				  my $error_loc ( @{ $error_hash{$error_code}{$error_desc} } )
				{
					my $child_text;
					if (   defined( $error_loc->{'attribute'} )
						&& defined( $error_loc->{'value'} ) )
					{

						$child_text =
						    $error_loc->{'attribute'} . "="
						  . $error_loc->{'value'};
					}

					my $parent_text = $error_loc->{'attribute_name'};

					if ( defined( $error_loc->{'attribute_value'} ) ) {
						$parent_text .= "=" . $error_loc->{'attribute_value'};
					}

					my $duplicate_text = $error_loc->{'attribute_name'};

					if ( defined( $error_loc->{'attribute'} ) ) {
						$duplicate_text .=
						  " (" . $error_loc->{'attribute'} . ")";
					}

					if ( !defined( $duplicate_attributes{$duplicate_text} ) ) {
						if ( !defined( $print_only_once{$parent_text} ) ) {
							print "\t\t$parent_text\n";
							$print_only_once{$parent_text} = 1;
						}
						if ( defined($child_text) ) {
							print "\t\t\t$child_text\n";
						}
						$duplicate_attributes{$duplicate_text} = 0;
					}
					else {
						if ( !defined( $print_only_once{$parent_text} ) ) {
							if ($all_errors) {
								print "\t\t$parent_text\n";
							}
							$print_only_once{$parent_text} = 1;
						}
						if ($all_errors) {
							if ( defined($child_text) ) {
								print "\t\t\t$child_text\n";
							}
						}
						$duplicate_attributes{$duplicate_text}++;
					}
				}

				if ( !$all_errors ) {
					foreach
					  my $duplicate_attribute ( keys %duplicate_attributes )
					{
						if ( $duplicate_attributes{$duplicate_attribute} > 0 ) {
							print "\t\t\t - Ignoring "
							  . $duplicate_attributes{$duplicate_attribute}
							  . " duplicate errors in $duplicate_attribute...\n";
						}
					}
				}
			}

			$found_errors{$error_code} = 1;

		}
		if ($attribute_valid) {

			#print "\n[ Success ] $attribute is valid\n";
		}
		else {
			print "\n[ Failure ] $attribute is not valid\n";
		}

		#print "-------\n";

	}

	if ($all_attributes_valid) {
		print "\n\n[ Success ] GIP Successfully Verfied\n\n";
		return 0;
	}
	else {
		print "\n\n[ Failure ] GIP Did Not Verify!!!\n\n";

		print
		  "Please see the following webpages for troubleshooting information\n";

		foreach my $error_code ( keys %found_errors ) {
			print "http://grow.uiowa.edu/dokuwiki/doku.php/projects/gluechecker/"
			  . $error_code . "\n";

		}
		return 1;
	}
}

sub strip_off_base {
	my ($dn, $base) = @_;

	my @dn_parts = split( /,/, $dn );
	my @base_parts = split( /,/, $base);

	while ($#base_parts > -1) {
		if ($#dn_parts == -1) {
			die "base $base is longer than dn $dn\n";
		}
		
		my $last_base_part = pop(@base_parts); trim(\$last_base_part);
		my $last_dn_part = pop(@dn_parts); trim(\$last_dn_part);
		
		if (lc($last_base_part) ne lc($last_dn_part)) {
			print "\n$last_base_part and $last_dn_part do not match\n\n";
			die "cannot strip base $base off of dn $dn\n";
		}
	}
	return @dn_parts;
}

sub add_entry {
	my ( $hashref, $entry, $base ) = @_;

	my $type;
	my $ref_return = ref($entry);
	if (ref($entry) eq 'ARRAY') {
		$type = 'ldif';
	} elsif (UNIVERSAL::isa($$entry, 'Net::LDAP::Entry')) {
		$type = 'ldap';
	} else {
		die "Not a recognized entry type";
	}

	my $dn;
	
	if ($type eq 'ldap') {
		$dn = $$entry->dn();
	} elsif ($type eq 'ldif') {
		$dn = $$entry[0];	
	}

	my @dn_parts = strip_off_base($dn, $base);

	# this makes the stuff in the hash for the dn
	my $i;
	for ( $i = $#dn_parts ; $i >= 0 ; $i-- ) {
		my $dn_part = $dn_parts[$i];

		if ($dn_part =~ /^\s*$/) {
			next;
		} else {

			my ( $dn_attr, $dn_value ) = split( /=/, $dn_part );
			trim( \$dn_attr );
			trim( \$dn_value );

			if ( !defined( $hashref->{$dn_attr} ) ) {
				$hashref->{$dn_attr} = {};
			}
			$hashref = $hashref->{$dn_attr};

			if ( !defined( $hashref->{$dn_value} ) ) {
				$hashref->{$dn_value} = {};
			}
			$hashref = $hashref->{$dn_value};
		}
	}
	
	my @attributes;
	
	if ($type eq 'ldap') {
		@attributes = $$entry->attributes();
	} elsif ($type eq 'ldif') {
		@attributes = @{$$entry[1]}
	}
	
	foreach my $attribute (@attributes) {
		my @values;
		
		if ($type eq 'ldap') {
			@values = $$entry->get_value($attribute);
		} elsif ($type eq 'ldif') {
			my $attribute_hashref = $$entry[2];
			#print Data::Dumper->Dump([$attribute_hashref]);
			@values = @{$attribute_hashref->{$attribute}};
		}
		
		if ( !defined( $hashref->{$attribute_store} ) ) {
			$hashref->{$attribute_store} = {};
		}
		if ( !defined( $hashref->{$attribute_store}{$attribute} ) ) {
			$hashref->{$attribute_store}{$attribute} = ();
		}
		push( @{ $hashref->{$attribute_store}{$attribute} }, @values );
	}
}

sub trim($) {
	my $string = shift;
	if ( defined($$string) ) {
		$$string =~ s/^\s+//;
		$$string =~ s/\s+$//;
	}
	else {
		$$string = "";
	}
}

sub debug_print {
	my ( $debug_level, $debug_string ) = @_;
	if ( $debug_level <= $verbose ) {
		print $debug_string;
	}
}

1;
