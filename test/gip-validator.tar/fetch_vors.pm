#! /usr/bin/perl -w

use strict;
use Socket;
use Data::Dumper;

#my $mapping = fetch_vors();
#print Data::Dumper->Dump([$mapping]);

sub get_http_data {
  my ($rem, $instring) = @_;
  my ($remote, $port, $iaddr, $paddr, $proto, $line);
  $remote = $rem;
  my $wholeline= "";
  $port = 80;
  $iaddr = inet_aton($remote) || die "ERROR, no host: $remote";
  $paddr = sockaddr_in($port, $iaddr);
  $proto = getprotobyname('tcp');
  socket(SOCK, PF_INET, SOCK_STREAM, $proto) || die "ERROR on socket: $!";
  connect(SOCK, $paddr) || die "ERROR on connect: $!";
  my $sendstring = "GET $instring\n";
  send SOCK, $sendstring, 0;
  while (defined($line = <SOCK>)) {
    $wholeline .= $line;
  }
  close (SOCK);
  return($wholeline);
}

sub fetch_vors {
	my ($grid)=@_;
	#my $grid = shift(@_);
	#my $type = shift(@_);
	
#	my $grid = 4;
	my $cmd = "/cgi-bin/tindex.cgi" . '?' . "grid=$grid";
	my $resp = get_http_data("vors.grid.iu.edu", $cmd);

	my @lines = split(/\n/, $resp);
	my %mapping = ();

	my $i = 0;
	foreach my $line (@lines) {
		if (! ($line =~ /^#/ || $line =~ /^\s*$/)) {
			my ($tmp, $sitename, $hostname) = split(/,/, $line);
			$hostname =~ s/:2119$//;
			$mapping{$sitename} = $hostname;
			$i++;
		}
	}

	return \%mapping;
}

1;
